A Flappy Bird Style Game

This game is a very simple representation of a tap and play game similar to "Flappy Bird".



- For an in-depth look at the creation of this project check out the accompanying series of live training videos at https://unity3d.com/learn/tutorials/topics/2d-game-creation/animating-bird
-

For more learn material, please check the learn section of our website:

http://unity3d.com/learn